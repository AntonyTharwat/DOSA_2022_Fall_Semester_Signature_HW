﻿namespace RestaurantManagementHomeWork4
{
    class person
    {
        public string personName { get; set; }
        public string phoneNumber { get; set; }
        public int noOfCompanions { get; set; }
    }
}
